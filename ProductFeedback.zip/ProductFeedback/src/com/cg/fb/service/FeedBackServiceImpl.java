package com.cg.fb.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.fb.dao.FeedBackDAO;
import com.cg.fb.dto.Feedback;

@Service("feedbackservice")
@Transactional

public class FeedBackServiceImpl implements FeedBackService{
	@Autowired
	FeedBackDAO feedbackdao;
	
	
	@Override
	public void addFeedback(Feedback fb) {
		// TODO Auto-generated method stub
		feedbackdao.addFeedback(fb);
	
		
	}

	
	public FeedBackServiceImpl(){
		
	}

	public float setAvgRating(String productId) {

		/*List<Integer> id = feedbackdao.getAvgRating(productId);
		int sum = 0;
		for (int i : id) {
			int rating = feedbackdao.getFeedback(i);

			sum = sum + rating;
		}
		float avgRating = (float)sum / id.size();
		Feedback product = feedbackdao.findProduct(productId);

		product.setAverageRating(avgRating);

		feedbackdao.save(product);
		return avgRating;*/

		Feedback fb=feedbackdao.findOne(productId);
		int sum=0;

		return 0;
	}

	@Override
	public float getAvgRating(String productId) {
		// TODO Auto-generated method stub
		return 0;
	}
	

	

	@Override
	public float getMerchantAvgRating(String merchantId) {
		return 0;
		/*List<Integer> id = feedbackdao.getProductList(mId);
		float sum = 0;
		for (int i : id) {
			float avgRating = feedbackdao.getProductAvgRating(i);
			sum = sum + avgRating;
		}
		float avgRating = (float)sum / id.size();
		Merchant merchant = feedbackdao.findMerchant(mId);
		merchant.setAverageRating(avgRating);
		feedbackdao.save(merchant);
		return avgRating;
*/
	}


	

	
	

}
