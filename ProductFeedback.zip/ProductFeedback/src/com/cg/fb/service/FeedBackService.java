package com.cg.fb.service;

import com.cg.fb.dto.Feedback;

public interface FeedBackService {
	public void addFeedback(Feedback fb);
	
	public float setAvgRating(String productId);

	public float getAvgRating(String productId);

	public float getMerchantAvgRating(String merchantId);

	
}