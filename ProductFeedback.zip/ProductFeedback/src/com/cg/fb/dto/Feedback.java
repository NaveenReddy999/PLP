package com.cg.fb.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name="Feedback")
public class Feedback {
	@Id
	@Column(name="User_id")
	private int userId;
	
	@Column(name="Order_id")
	private int orderId;
	
	@Column(name="Product_id")
	private int productId;
	
	@Column(name="Rating")
	private float userRating;
	
	@Column(name="Reviews")
	private String userReview;
	
	
	@Column
	private float merchantId;

	public Feedback() {
		super();
		// TODO Auto-generated constructor stub
	}

	

	public Feedback(int orderId, int productId, int userId, String userReview,
			float userRating, float merchantId) {
		super();
		this.orderId = orderId;
		this.productId = productId;
		this.userId = userId;
		this.userReview = userReview;
		this.userRating = userRating;
		this.merchantId = merchantId;
	}



	public int getOrderId() {
		return orderId;
	}

	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}

	public int getProductId() {
		return productId;
	}

	public void setProductId(int productId) {
		this.productId = productId;
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public String getUserReview() {
		return userReview;
	}

	public void setUserReview(String userReview) {
		this.userReview = userReview;
	}

	public float getUserRating() {
		return userRating;
	}

	public void setUserRating(float userRating) {
		this.userRating = userRating;
	}



	public float getMerchantId() {
		return merchantId;
	}



	public void setMerchantId(float merchantId) {
		this.merchantId = merchantId;
	}



	@Override
	public String toString() {
		return "Feedback [orderId=" + orderId + ", productId=" + productId
				+ ", userId=" + userId + ", userReview=" + userReview
				+ ", userRating=" + userRating + ", merchantId=" + merchantId
				+ "]";
	}

	

	

}
