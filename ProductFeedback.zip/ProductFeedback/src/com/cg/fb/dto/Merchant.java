package com.cg.fb.dto;

public class Merchant {
	
	private String merchantId;
	
	

}
