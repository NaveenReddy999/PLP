package com.cg.fb.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.jboss.resteasy.annotations.Query;
import org.springframework.stereotype.Repository;

import com.cg.fb.dto.Feedback;
import com.cg.fb.dto.Merchant;
@Repository("feedbackdao")

public class FeedBackDAOImpl implements FeedBackDAO {
	@PersistenceContext
	EntityManager em;

public void addFeedback(Feedback fb){
	em.persist(fb);	
	em.flush();

}

@Override
public boolean save(Feedback feedback) {

	if(feedback!=null){
		em.persist(feedback);	
		em.flush();
		return true;
	}
	return false;
}

@Override
public Feedback findOne(String productId) {
	
	Feedback fbsearch=em.find(Feedback.class, productId);
	return fbsearch;
}
/*@Query(value = "SELECT feed_back.rating FROM feed_back  WHERE feed_back.id=?1", nativeQuery = true)
public int getFeedback(int fId);*/



}
